
package rc;
// Filename DakiLearnerTask2Prj
// Written on < 5/4/24 >
// Written by < Luzuko Daki >
import javax.swing.JOptionPane;
/**
 *
 * @author RC_Student_lab
 */
public class DakiLearnerTask2Prj {
    
   
    
    static Learner objLearner = new Learner (); //linking my Learner class with the main page
    public static void main(String[] args) {
        // using method to get user input
        getLearnerInput();
        // using method to display the final mark
       
       
    }
    public static void getLearnerInput(){
        objLearner.setfullName(JOptionPane.showInputDialog("Enter you full name "));
        objLearner.setsubjectName(JOptionPane.showInputDialog("Please enter subjectName "));
        objLearner.setassignmentMark(Integer.parseInt(JOptionPane.showInputDialog("Please enter assignment mark")));
        objLearner.settestMark(Integer.parseInt(JOptionPane.showInputDialog("Please enter test mark")));
        objLearner.setexamMark(Integer.parseInt(JOptionPane.showInputDialog("Pleas enter exam mark")));
    }


    
    public static void getdisplayFinalMark(){
        double displayFinalMark = objLearner.calcFinalMark();
        JOptionPane.showInternalMessageDialog(null,displayFinalMark);
    }
}
