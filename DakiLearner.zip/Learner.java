/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rc;
// Filename Learner
// Written on < 5/4/24 >
// Written by < Luzuko Daki >

/**
 *
 * @author RC_Student_lab
 */
class Learner {
     // Class created
        // Attributes created in class
       String fullName;
       String subjectName;
       int assignmentMark;
       int testMark;
       int examMark;
        
       // Using constructors to set values to the atributes
       public Learner (){
           this.fullName = ("");
           this.subjectName = ("");
           this.assignmentMark = (0);
           this.testMark = (0);
           this.examMark = (0);
       }
           // Using getters to return values for the attributes
           public String getfullName(){
             return this.fullName;
           }
            public String getsubjectName(){
             return this.subjectName;
           }
            public int getassignmentMark(){
             return this.assignmentMark;
           }
             public int gettestMark(){
             return this.testMark;
           }
              public int getexamMark(){
             return this.examMark;
           }
       // Using setters to return values for the attributes
              public void setfullName (String showInputDialog){
                  this.fullName = fullName;
              }
              public void setsubjectName (String showInputDialog){
                  this.subjectName = subjectName;
              }
              public void setassignmentMark (int parseInt){
                  this.assignmentMark = assignmentMark;
              }
              public void settestMark (int parseInt){
                  this.testMark = testMark;
              }
              public void setexamMark (int parseInt){
                  this.examMark = examMark;
              }
              // This method is used to calculate the final mark
             public double calcFinalMark(){
                 return (getassignmentMark() * gettestMark() + getexamMark() )/3;
             }

    
         
                
    
}
